//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by plxReader.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PLXREADER_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_DATA_LIST                   1000
#define IDC_CHANNEL                     1001
#define IDC_UNIT                        1002
#define IDC_STATIC_CHANNEL              1003
#define IDC_COMMANDS                    1004
#define IDC_LISTING                     1004
#define IDC_INFO                        1005
#define IDC_FILENAME                    1006
#define IDC_BROWSE                      1007
#define IDC_DATA_START                  1008
#define IDC_DATA_END                    1009
#define IDC_READ_FILE                   1011
#define IDC_FILE_INFO                   1012
#define IDC_EXTRACT                     1012
#define IDC_DONE                        1013
#define IDC_UPDATE                      1014
#define IDC_TREE                        1016
#define IDC_PROGRESS                    1022
#define IDC_LIST                        1025
#define IDC_BUTTON_HEADER               1027
#define IDC_CHECK_SPIKE                 1028
#define IDC_CHECK_EVENT                 1029
#define IDC_CHECK_SLOW                  1030
#define IDC_LIST_SLOWS                  1033
#define IDC_LIST_HEADER                 1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
